/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package testjunit;

import org.junit.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * @author Shade
 */
public class AdditionTest extends TestCase {

    private int x = 1;
    private int y = 1;

    @Test
    public void testAddition() {
        int z = x + y;
        assertEquals(2, z);
    }

    @Override
    public void runTest() {
        testAddition();
    }
}
