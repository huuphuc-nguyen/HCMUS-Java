/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package testjunit;

import org.junit.Test;
import junit.framework.TestCase;

/**
 * @author Shade
 */
public class CounterTest  extends TestCase {

    Counter counter1;

    public CounterTest(){}//default constructor

    @Override
    protected void setUp(){//create  a (simple) test fixture
        counter1 = new Counter();
    }

    @Override
    protected void tearDown(){}

    @Test
    public void testIncrement() {
        assertTrue(counter1.increment() == 1);
        assertTrue(counter1.increment() == 2);
    }

    public void testDecrement() {
        assertTrue(counter1.decrement() == -1);
    }
}
