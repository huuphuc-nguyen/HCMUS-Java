/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package testjunit;

/**
 *
 * @author Shade
 */
public class Counter {

    int count = 0;

    public int increment() {
        return ++count;
    }

    public int decrement() {
        return --count;
    }

    public int getCount() {
        return count;
    }
}
